//
//  MessagesView.swift
//  iChat
//
//  Created by ALYSSON MENEZES  on 18/03/22.
//

import SwiftUI
import FirebaseAuth

struct  MessagesView: View {
    @StateObject var viewModel = MessagesViewModel()
    var body: some View {
      
        Button {
            viewModel.logOut()
        } label: {
            Text( " LogOut")
            }
        }
    }


struct MessagesView_Previews: PreviewProvider {
    static var previews: some View {
        MessagesView()
    }
}
