//
//  iChatApp.swift
//  iChat
//
//  Created by ALYSSON MENEZES  on 12/03/22.
//
import SwiftUI
import Firebase
import FirebaseAuth

@main


struct iChatApp: App {
    
    init(){
        FirebaseApp.configure()
       // try! Auth.auth().signOut() // delogar no firebase  
    }
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
    
}

