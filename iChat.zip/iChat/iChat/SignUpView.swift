//
//  SignInUpView.swift
//  iChat
//
//  Created by ALYSSON MENEZES  on 12/03/22.
//

import SwiftUI
struct SignUpView: View {
    @StateObject var viewModel = SignUpViewModel() // puxando dados de outro aqrquvio
    @State var isShowPhotoLibrary = false
     var body: some View {
         VStack{
        
             Button {
                 isShowPhotoLibrary = true
             }label: {
                 if viewModel.image.size.width > 0 {
                     Image( uiImage: viewModel.image)
                         .resizable()
                         .scaledToFill()
                         .frame(width: 130, height: 130)
                         .clipShape(Circle())
                         .overlay(Circle().stroke(Color( "BlueColor"),
                            lineWidth: 4))
                         .shadow( radius: 10)
                     
                 }else {
                        
                 Text( "Foto")
                     .frame(width: 130, height: 130)
                     .padding()
                     .background(Color("BlueColor"))
                     .foregroundColor(Color.white)
                     .cornerRadius(100.0)
             }
        }
             .padding(.bottom, 100)
             .sheet(isPresented: $isShowPhotoLibrary){
                 ImagePicker(selectedImage: $viewModel.image)
             }
             
             TextField("Entre com seu nome ", text: $viewModel.name)
                 .autocapitalization(.none)// desativa caixa alta do teclado
                 .disableAutocorrection(false)
                 .padding()
                 .background(Color.white)
                 .cornerRadius(10.0)
                 .overlay(
                     RoundedRectangle(cornerRadius: 10.0)
                         .stroke(Color(UIColor.separator),
                                 style: StrokeStyle(lineWidth: 2.0))
                 )
                 .padding(.bottom, 20)
             
             TextField("e-mail", text: $viewModel.email)
                 .autocapitalization(.none)// desativa caixa alta do teclado
                 .disableAutocorrection(false)
                 .padding()
                 .background(Color.white)
                 .cornerRadius(10.0)
                 .overlay(
                     RoundedRectangle(cornerRadius: 10.0)
                         .stroke(Color(UIColor.separator),
                                 style: StrokeStyle(lineWidth: 2.0))
                 )
                 .padding(.bottom, 20)
             
             
             SecureField("password", text: $viewModel.password)
                 .autocapitalization(.none)// desativa caixa alta do teclado
                 .disableAutocorrection(false)
                 .padding()
                 .background(Color.white)
                 .cornerRadius(10.0)
                 .overlay(
                     RoundedRectangle(cornerRadius: 10.0)
                         .stroke(Color(UIColor.separator),
                                 style: StrokeStyle(lineWidth: 3.0))
                 )
                 .padding(.bottom, 30)
             
             if viewModel.isLoading{ // loading
                 ProgressView()
                     .padding()
             }
             Button {
            viewModel.signUp()
             }label:{
                 Text( "Criar")}
             .frame(maxWidth: .infinity)
             .padding()
             .background(Color("BlueColor"))
             .cornerRadius(10.0)
             .foregroundColor(Color.white)
             // obs: a ordem das coisas fazem a diferença !!
         }
         .alert(isPresented: $viewModel.formInvalid) {
             Alert( title: Text( viewModel.alertText))
         }
         
         .frame(maxWidth: .infinity, maxHeight: .infinity)// cor na tela toda
         .padding(.horizontal,32)
         .background(Color.init(red: 245 / 255, green: 245 / 255, blue: 245 / 255)) // cor rgb
         .navigationBarTitleDisplayMode(.inline)
     }
     }



struct SignInUpView_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            SignUpView()
            SignUpView()
        }
    }
}
