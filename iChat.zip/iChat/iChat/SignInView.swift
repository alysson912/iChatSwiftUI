//
//  ContentView.swift
//  iChat
//
//  Created by ALYSSON MENEZES  on 12/03/22.
//

import SwiftUI

struct SignInView: View {
    
   @StateObject var viewModel = SignInViewModel() // puxando dados de outro aqrquvio
    
    var body: some View {
    
    NavigationView{ // container principal para navergar entr telas
        VStack{
            Image("logo")
                .resizable()
                .scaledToFit()
                .padding()
            
            TextField("e-mail", text: $viewModel.email)
                .autocapitalization(.none)// desativa caixa alta do teclado
                .disableAutocorrection(false)
                .padding()
                .background(Color.white)
                .cornerRadius(10.0)
                .overlay(
                    RoundedRectangle(cornerRadius: 10.0)
                        .stroke(Color(UIColor.separator),
                                style: StrokeStyle(lineWidth: 2.0))
                )
                .padding(.bottom, 20)
            
            
            SecureField("password", text: $viewModel.password)
                .autocapitalization(.none)// desativa caixa alta do teclado
                .disableAutocorrection(false)
                .padding()
                .background(Color.white)
                .cornerRadius(10.0)
                .overlay(
                    RoundedRectangle(cornerRadius: 10.0)
                        .stroke(Color(UIColor.separator),
                                style: StrokeStyle(lineWidth: 2.0))
                )
                .padding(.bottom, 30)
            
            if viewModel.isLoading{
                ProgressView()
                    .padding()
            }
            
            Button {
                viewModel.signIn()
            }label:{
                Text( "Entrar")}
            .frame(maxWidth: .infinity)
            .padding()
            .background(Color("BlueColor"))
            .cornerRadius(10.0)
            .foregroundColor(Color.white)
        // obs: a ordem das coisas fazem a diferença !!
        
        .alert(isPresented: $viewModel.formInvalid) {
            Alert( title: Text( viewModel.alertText))
        }
         
            Divider()
            .padding()
            
            NavigationLink( // navegação entre  telas
                destination: SignUpView()){
                    Text("Não tem uma conta ? Clique aqui")
                }
    
            }
        
        .frame(maxWidth: .infinity, maxHeight: .infinity)// cor na tela toda
        .padding(.horizontal,32)
        .background(Color.init(red: 245 / 255, green: 245 / 255, blue: 245 / 255)) // cor botao/ rgb
        .navigationTitle("Login")
        .navigationBarHidden(true)
        }
    }


struct SignInView_Previews: PreviewProvider {
    static var previews: some View {
        SignInView()
    }
}

}
