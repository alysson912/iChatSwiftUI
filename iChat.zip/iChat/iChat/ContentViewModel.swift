//
//  ContentViewModel.swift
//  iChat
//
//  Created by ALYSSON MENEZES  on 18/03/22.
//

import Foundation
import FirebaseAuth

class ContentViewModel : ObservableObject {
    
    @Published var isLogged = Auth.auth().currentUser != nil
    
}
