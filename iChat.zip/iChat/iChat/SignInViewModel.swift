//
//  SignInViewModel.swift
//  iChat
//
//  Created by ALYSSON MENEZES  on 12/03/22.
//

import Foundation
import FirebaseAuth

class SignInViewModel: ObservableObject {
    
    @Published var email = ""
    @Published var password = ""
    
    @Published var formInvalid = false
    @Published var alertText = ""
    @Published var isLoading = false
    
    func signIn(){
        print( "email: \(email), senha: \(password)")
        isLoading = true
        
        Auth.auth().signIn(withEmail: email,password: password){
         result, err in
            
                guard let user = result?.user, err == nil else {
                    self.formInvalid = true
                    self.alertText = err!.localizedDescription
                    print(err)
                    self.isLoading = false
                    return
                }
                self.isLoading = false
                print(" usuário logado : \(user.uid) ")
            }
        }
    }

