//
//  MessagesViewModel.swift
//  iChat
//
//  Created by ALYSSON MENEZES  on 18/03/22.
//

import Foundation
import FirebaseAuth


class MessagesViewModel : ObservableObject{
    func logOut() {
        try? Auth.auth().signOut()
    }
}
